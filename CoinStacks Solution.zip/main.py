import studentsolver


def grid_from_lines(lines):
  grid = []
  for line in lines:
    values = line.split(' ')
    grid_line = []
    for value in values:
      grid_line.append(int(value))
    grid.append(grid_line)
  return grid



def test_with_input_file():
  with open('input', 'r+') as f:
    lines = f.readlines()
  
  grid = grid_from_lines(lines)
  studentsolver.print_grid(grid)
  print()
  num_coins = studentsolver.solve(grid)
  print()
  print(num_coins)

test_with_input_file()
